Windows Sidebar Install readme
-------------------------------


1. �nce Alky For Applications y�kle
2. sonra Windows_Sidebar_Installer.exe yi y�kle
3. sonra Gadget Extractor � y�kle


Info about the softwares
-------------------------------

Alky For Applications: Alky makes it possible to open software
That is created for Windows Vista.
Just like the Sidebar.

Windows_Sidebar_Installer: This is the Windows Sidebar installer.

Gadget Extractor: Gadget Extractor makes it possible to add new gadgets
to your Sidebar, Just open Gadget files with Gadget Extractor.
And Gadget Extractor adds the gadget to your Sidebar Gadget List.

Enjoy!


Package & Readme created by Joshoon.
I am also a (hard)dance/eurodance producer and vocalist.
If you wanna check out some of my music, you can check out my website www.djjoshoon.com
Or my YouTube account: www.youtube.com/user/JoshoonJH





The software is not made by me!
I only put all the software you needed together in a pack to make it more simple for you guys.

All software credits going to: 
Falling Leaf Systems and Ricktendo64